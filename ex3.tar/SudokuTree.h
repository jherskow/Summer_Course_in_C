/**
 * @file SudokuTree.h
 * @author  jjherskow <jherskow@cs.huji.ac.il>
 * @date //todo
 *
 * @brief //todo
 */


// ------------------------------ includes ------------------------------
#include <stdio.h>

// -------------------------- global definitions ------------------------

#define  MAX_N 100

// ------------------------------ functions -----------------------------

